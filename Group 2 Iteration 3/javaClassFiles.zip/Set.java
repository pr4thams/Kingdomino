import java.util.ArrayList;

public class Set {
	
	static ArrayList<Domino> set;
	public Set()
	{
		
	}
}

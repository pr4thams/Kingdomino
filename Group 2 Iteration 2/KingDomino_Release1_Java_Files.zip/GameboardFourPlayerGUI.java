package KingDomino;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import javax.swing.BorderFactory;
import javax.swing.border.Border;
import java.util.Random;

public class GameboardFourPlayerGUI 
{
    // instance variables - replace the example below with your own
    private JFrame frame;
    private JPanel panelPlayer1;
    private JPanel panelPlayer2;
    private JPanel panelPlayer3;
    private JPanel panelPlayer4;
    private JPanel panelD;
    
    private JButton button1;
    private JButton button2;
    private JButton button3;
    
    private JButton wheatfield;
    private JButton grasslands;
    private JButton forests1;
    private JButton forests2;
    private JButton forests3;
    private JButton lakes;
    private JButton mines;
    private JButton swamps;
    
    private JPanel Domino1;
    private JPanel Domino2;
    private JPanel Domino3;
    private JPanel Domino4;
    
    private JButton KMeeple1;
    private JButton KMeeple2;
    private JButton KMeeple3;
    private JButton KMeeple4;
    private JButton KMeeple5;
    private JButton KMeeple6;
    private JButton KMeeple7;
    private JButton KMeeple8;
    
    private JLabel p1;
    private JLabel p2;
    private JLabel p3;
    private JLabel p4;
    /**
     * Constructor for objects of class Gameboard
     */
    public GameboardFourPlayerGUI()
    {
        // initialise instance variables
        frame = new JFrame();
        Container contentPane = frame.getContentPane();
        contentPane.setLayout(new BorderLayout(12,12));
        //Pamel Player 1
        panelPlayer1=new JPanel();
        contentPane.add(panelPlayer1,BorderLayout.WEST);
        panelPlayer1.setLayout(new BorderLayout());
        
        p1 = new JLabel("Player 1");
        KMeeple1 = new JButton("King Meeple 1");
        KMeeple1.setPreferredSize(new Dimension(100,40));
        KMeeple1.setBackground(Color.PINK);
        KMeeple2 = new JButton("King Meeple 2");
        KMeeple2.setPreferredSize(new Dimension(100,40));
        KMeeple2.setBackground(Color.PINK);
        
        panelPlayer1.add(p1,BorderLayout.CENTER);
        panelPlayer1.add(KMeeple1,BorderLayout.NORTH);
        panelPlayer1.add(KMeeple2,BorderLayout.SOUTH);
        
        //Pamel Player 2
        panelPlayer2=new JPanel();
        contentPane.add(panelPlayer2,BorderLayout.EAST);
        panelPlayer2.setLayout(new BorderLayout());
        
        p2 = new JLabel("Player 2");
        KMeeple3 = new JButton("King Meeple 1");
        KMeeple3.setPreferredSize(new Dimension(100,40));
        KMeeple3.setBackground(Color.YELLOW);
        KMeeple4 = new JButton("King Meeple 2");
        KMeeple4.setPreferredSize(new Dimension(100,40));
        KMeeple4.setBackground(Color.YELLOW);
        
        panelPlayer2.add(p2,BorderLayout.EAST);
        panelPlayer2.add(KMeeple3,BorderLayout.NORTH);
        panelPlayer2.add(KMeeple4,BorderLayout.SOUTH);
        
        //Pamel Player 3
        panelPlayer3=new JPanel();
        contentPane.add(panelPlayer3,BorderLayout.NORTH);
        panelPlayer3.setLayout(new GridLayout(0,3));
        
        p3 = new JLabel("Player 3");
        JPanel pleft=new JPanel();
        JPanel pright=new JPanel();
        JPanel pmiddle=new JPanel();
        pmiddle.setLayout(new GridLayout(3,0));
        KMeeple5 = new JButton("King Meeple 1");
        KMeeple5.setPreferredSize(new Dimension(100,40));
        KMeeple5.setBackground(Color.GREEN);
        //KMeeple5.addActionListener(this);
        KMeeple6 = new JButton("King Meeple 2");
        KMeeple6.setPreferredSize(new Dimension(100,40));
        KMeeple6.setBackground(Color.GREEN);
        //KMeeple6.addActionListener(this);
        
        panelPlayer3.add(pleft);
        panelPlayer3.add(pmiddle);
        panelPlayer3.add(pright);
        pmiddle.add(KMeeple5);
        pmiddle.add(p3);
        pmiddle.add(KMeeple6);
        
        //Pamel Player 4
        panelPlayer4=new JPanel();
        contentPane.add(panelPlayer4,BorderLayout.SOUTH);
        panelPlayer4.setLayout(new GridLayout(0,3));
        
        p4 = new JLabel("Player 4");
        JPanel pleft1=new JPanel();
        JPanel pright1=new JPanel();
        JPanel pmiddle1=new JPanel();
        pmiddle1.setLayout(new GridLayout(3,0));
        KMeeple7 = new JButton("King Meeple 1");
        KMeeple7.setPreferredSize(new Dimension(100,40));
        KMeeple7.setBackground(Color.RED);
        //KMeeple7.addActionListener(this);
        KMeeple8 = new JButton("King Meeple 2");
        KMeeple8.setPreferredSize(new Dimension(100,40));
        KMeeple8.setBackground(Color.RED);
        
        panelPlayer4.add(pleft1);
        panelPlayer4.add(pmiddle1);
        panelPlayer4.add(pright1);
        pmiddle1.add(KMeeple7);
        pmiddle1.add(p4);
        pmiddle1.add(KMeeple8);
        
        
        panelD=new JPanel();
        contentPane.add(panelD,BorderLayout.CENTER);
        panelD.setLayout(new BoxLayout(panelD,BoxLayout.Y_AXIS));
        
        wheatfield=new JButton("wheatfield");
        wheatfield.setPreferredSize(new Dimension(100,20));
        wheatfield.setBackground(new Color(255, 204, 51));
        grasslands=new JButton("grasslands");
        grasslands.setPreferredSize(new Dimension(100,20));
        grasslands.setBackground(new Color(204, 255, 102));
        forests1=new JButton("forests");
        forests1.setPreferredSize(new Dimension(100,20));
        forests1.setBackground(new Color(51, 102, 0));
        forests2=new JButton("forests");
        forests2.setPreferredSize(new Dimension(100,20));
        forests2.setBackground(new Color(51, 102, 0));
        forests3=new JButton("forests");
        forests3.setPreferredSize(new Dimension(100,20));
        forests3.setBackground(new Color(51, 102, 0));
        lakes=new JButton("lakes");
        lakes.setPreferredSize(new Dimension(100,20));
        lakes.setBackground(new Color(51, 153, 255));
        mines=new JButton("mines");
        mines.setPreferredSize(new Dimension(100,20));
        mines.setBackground(new Color(153, 153, 153));
        swamps=new JButton("swamps");
        swamps.setPreferredSize(new Dimension(100,20));
        swamps.setBackground(new Color(204, 204, 153));
        
        Domino1=new JPanel();
        Domino1.add(wheatfield,BorderLayout.LINE_START);
        Domino1.add(grasslands,BorderLayout.LINE_END);
        Domino1.add(new JLabel("Domino 1"),BorderLayout.NORTH);
        panelD.add(Domino1);
        
        Domino2=new JPanel();
        Domino2.add(lakes,BorderLayout.LINE_START);
        Domino2.add(mines,BorderLayout.LINE_END);
        panelD.add(Domino2);
        Domino2.add(new JLabel("Domino 2"),BorderLayout.NORTH);
        
        Domino3=new JPanel();
        Domino3.add(forests1,BorderLayout.LINE_START);
        Domino3.add(swamps,BorderLayout.LINE_END);
        panelD.add(Domino3);
        Domino3.add(new JLabel("Domino 3"),BorderLayout.NORTH);
        
        Domino4=new JPanel();
        Domino4.add(forests2,BorderLayout.LINE_START);
        Domino4.add(forests3,BorderLayout.LINE_END);
        panelD.add(Domino4);
        Domino4.add(new JLabel("Domino 4"),BorderLayout.NORTH);
        
        
        button1=new JButton("Scores");
        //contentPane.add(button1);
        button2=new JButton("Save & Quit");
        //contentPane.add(button2);
        button3=new JButton("Quit");
        //contentPane.add(button3);
        
        
        
       
        
        frame.setResizable(false);
        frame.setVisible(true);
        frame.setSize(800,600); //frame.pack();
    }

    
    
}
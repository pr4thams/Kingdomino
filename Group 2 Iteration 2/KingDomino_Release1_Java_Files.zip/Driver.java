package KingDomino;

public class Driver {

    public static void main(String[] args) {
        // TODO Auto-generated method stub
        //GameBoard board = new GameBoard();
        new MainMenuGUI();
    }

}